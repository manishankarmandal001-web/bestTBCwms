/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { WmsProduct, WmsClaim, UserSession, ThemeColor } from './types/wms';
import { storage } from './services/storage';
import { cloudSync } from './services/cloudSync';
import { themeService } from './services/theme';
import { ToastContainer, ToastMessage } from './components/Toast';
import { ProofLightbox } from './components/ProofLightbox';
import { LoginModal } from './components/LoginModal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminPortal } from './components/AdminPortal';
import { CustomerPortal } from './components/CustomerPortal';
import { OfflineIndicator } from './components/OfflineIndicator';

export type PortalMode = 'admin' | 'customer';

export default function App() {
  // Portal Entry Point state ('customer' or 'admin')
  const [activePortal, setActivePortal] = useState<PortalMode>(() => {
    // Check URL hash, search, or path (e.g. #admin, ?portal=admin, /admin)
    if (typeof window !== 'undefined') {
      const hash = window.location.hash.toLowerCase();
      const search = window.location.search.toLowerCase();
      const path = window.location.pathname.toLowerCase();
      if (hash.includes('admin') || search.includes('admin') || path.endsWith('/admin')) {
        return 'admin';
      }
      if (hash.includes('customer') || search.includes('customer')) {
        return 'customer';
      }
    }
    return 'customer'; // Default clean customer storefront
  });

  const [language, setLanguage] = useState<'en' | 'bn'>('en');

  // Customer Session details
  const [customerSession, setCustomerSession] = useState<{
    name: string;
    phone: string;
    email: string;
  }>(() => {
    try {
      const saved = localStorage.getItem('tbc_wms_customer_session');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      name: '',
      phone: '',
      email: ''
    };
  });

  const [isCustomerLoggedIn, setIsCustomerLoggedIn] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('tbc_wms_customer_session');
      if (saved) {
        const parsed = JSON.parse(saved);
        return Boolean(parsed && parsed.phone && parsed.name);
      }
    } catch {}
    return false; // Defaults to unauthenticated so clicking Submit 3 Proofs prompts login/signup
  });

  // Admin Authentication Session (No default demo account - admin must sign up or log in)
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('tbc_wms_admin_session');
      if (saved) {
        const parsed = JSON.parse(saved);
        return Boolean(parsed && parsed.email && parsed.type === 'admin');
      }
    } catch {}
    return false;
  });

  const [adminUser, setAdminUser] = useState<UserSession | null>(() => {
    try {
      const saved = localStorage.getItem('tbc_wms_admin_session');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.email && parsed.type === 'admin') return parsed;
      }
    } catch {}
    return null;
  });

  // Color Theme Customization state (default: Indigo with crisp white background)
  const [currentTheme, setCurrentTheme] = useState<ThemeColor>(() => themeService.getTheme());
  const themeConfig = themeService.getConfig(currentTheme);

  // Modals
  const [isCustomerLoginModalOpen, setIsCustomerLoginModalOpen] = useState(false);
  const [isAdminLoginModalOpen, setIsAdminLoginModalOpen] = useState(false);

  // Core Data
  const [products, setProducts] = useState<WmsProduct[]>([]);
  const [claims, setClaims] = useState<WmsClaim[]>([]);

  // Lightbox
  const [lightboxData, setLightboxData] = useState<{
    isOpen: boolean;
    imageUrl: string;
    title: string;
    subtitle?: string;
  }>({
    isOpen: false,
    imageUrl: '',
    title: '',
    subtitle: ''
  });

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // 1. Initial Data Load & 2. Real-Time Cross-Device / Cross-Tab Synchronization
  useEffect(() => {
    // Initial fetch from storage (filtered by known deleted IDs)
    setProducts(storage.getProducts());
    setClaims(storage.getClaims());

    // Immediate server fetch to ensure any newly deleted products on other devices are synced right away
    cloudSync.fetchProducts().then((res) => {
      if (res && Array.isArray(res.products)) {
        if (res.deletedProductIds && res.deletedProductIds.length > 0) {
          storage.syncDeletedProductIds(res.deletedProductIds);
        }
        const clean = storage.filterOutDeleted(res.products);
        storage.saveProducts(clean);
        setProducts(clean);
      }
    });

    // Subscribe to real-time cloud and broadcast sync
    // When ANY product is deleted, edited, or added on ANY device or tab, this immediately updates state!
    const unsubscribe = cloudSync.subscribe((latestProducts) => {
      setProducts(latestProducts);
    });

    // Listen to hash and popstate changes in URL (e.g. typing #admin or navigating)
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase();
      const search = window.location.search.toLowerCase();
      const path = window.location.pathname.toLowerCase();
      if (hash.includes('admin') || search.includes('admin') || path.endsWith('/admin')) {
        setActivePortal('admin');
      } else {
        setActivePortal('customer');
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    window.addEventListener('popstate', handleHashChange);

    return () => {
      unsubscribe();
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('popstate', handleHashChange);
    };
  }, []);

  // Sync portal mode to hash
  const handleSwitchPortal = (mode: PortalMode) => {
    setActivePortal(mode);
    try {
      if (mode === 'admin') {
        window.location.hash = 'admin';
      } else {
        window.location.hash = '';
      }
    } catch {}
  };

  const addToast = (type: 'success' | 'error' | 'info', title: string, message: string) => {
    const newToast: ToastMessage = {
      id: `toast-${Date.now()}-${Math.random()}`,
      type,
      title,
      message
    };
    setToasts((prev) => [...prev, newToast]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const handleSelectTheme = (theme: ThemeColor) => {
    setCurrentTheme(theme);
    themeService.setTheme(theme);
    addToast(
      'success',
      'Theme Updated',
      'Accent color updated successfully.'
    );
  };

  // Customer Login / Signup Handlers (Clean user data - no demo fallbacks)
  const handleCustomerLoginSuccess = (session: UserSession) => {
    setCustomerSession({
      name: session.name,
      phone: session.phone || '',
      email: session.email || ''
    });
    setIsCustomerLoggedIn(true);
    try {
      localStorage.setItem('tbc_wms_customer_session', JSON.stringify({
        name: session.name,
        phone: session.phone || '',
        email: session.email || ''
      }));
    } catch {}
    setIsCustomerLoginModalOpen(false);
    addToast('success', 'Logged In Successfully', `Welcome, ${session.name}! Ready to claim cashbacks.`);
  };

  const handleCustomerLogout = () => {
    setIsCustomerLoggedIn(false);
    setCustomerSession({
      name: '',
      phone: '',
      email: ''
    });
    try {
      localStorage.removeItem('tbc_wms_customer_session');
    } catch {}
    addToast('info', 'Logged Out', 'Signed out of customer account.');
  };

  // Admin Login Handlers (Protected access)
  const handleAdminLoginSuccess = (session: UserSession) => {
    setAdminUser(session);
    setIsAdminLoggedIn(true);
    try {
      localStorage.setItem('tbc_wms_admin_session', JSON.stringify(session));
    } catch {}
    setIsAdminLoginModalOpen(false);
    handleSwitchPortal('admin');
    addToast('success', 'Admin Access Granted', `Logged in as ${session.name}.`);
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setAdminUser(null);
    try {
      localStorage.removeItem('tbc_wms_admin_session');
    } catch {}
    handleSwitchPortal('customer');
    addToast('info', 'Admin Logged Out', 'Signed out of administrator console.');
  };

  // Product Actions (Real-Time Synchronized across all devices)
  const handleSaveProduct = (savedProduct: WmsProduct) => {
    const exists = products.some((p) => p.id === savedProduct.id);
    let updated: WmsProduct[];
    if (exists) {
      storage.updateProduct(savedProduct.id, savedProduct);
      updated = storage.getProducts();
      addToast(
        'success',
        'Product Updated',
        `"${savedProduct.title}" updated successfully.`
      );
    } else {
      storage.addProduct(savedProduct);
      updated = storage.getProducts();
      addToast(
        'success',
        'New Offer Published',
        `"${savedProduct.title}" published and synchronized across all portals.`
      );
    }
    setProducts(updated);
  };

  // Delete product - instantly removed from customer portal & all devices
  const handleDeleteProduct = (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    const prodTitle = prod ? prod.title : 'Product';

    // 1. Immediately remove from React state (0ms instant removal on screen)
    setProducts((prev) => prev.filter((p) => p.id !== productId));

    // 2. Persist to storage, blacklist, broadcast across tabs, and tell server
    storage.deleteProduct(productId);

    addToast(
      'info',
      'Product Deleted',
      `"${prodTitle}" immediately deleted across Customer Portal and all connected devices.`
    );
  };

  const handleToggleProductStatus = (productId: string) => {
    const p = products.find((prod) => prod.id === productId);
    if (!p) return;
    const nextStatus = p.status === 'active' ? 'paused' : 'active';
    storage.updateProduct(productId, { status: nextStatus });
    setProducts(storage.getProducts());
    addToast('info', 'Status Updated', `${p.title} is now ${nextStatus}.`);
  };

  // Claim Actions
  const handleApproveClaim = (claimId: string) => {
    storage.updateClaim(claimId, { status: 'Approved' });
    setClaims(storage.getClaims());
    addToast(
      'success',
      'Claim Proofs Approved',
      'Claim moved to UPI disbursement queue.'
    );
  };

  const handleRejectClaim = (claimId: string, reason: string) => {
    storage.updateClaim(claimId, {
      status: 'Rejected',
      rejectionReason: reason
    });
    setClaims(storage.getClaims());
    addToast(
      'error',
      'Claim Rejected',
      `Reason: ${reason}`
    );
  };

  const handleConfirmPayout = (claimId: string, utrRef: string) => {
    storage.recordPayout(claimId, utrRef, adminUser ? adminUser.name : 'Authorized Admin');
    setClaims(storage.getClaims());
    addToast(
      'success',
      'UPI Payout Complete',
      `Banking UTR ${utrRef} recorded successfully.`
    );
  };

  const handleSubmitCustomerClaim = (newClaim: WmsClaim) => {
    storage.addClaim(newClaim);
    setClaims(storage.getClaims());
    // Increment claimed slots
    const prod = products.find((p) => p.id === newClaim.productId);
    if (prod) {
      storage.updateProduct(prod.id, { claimedSlots: prod.claimedSlots + 1 });
      setProducts(storage.getProducts());
    }
    addToast(
      'success',
      'Claim Submitted Successfully',
      'Your screenshots and UPI ID are submitted for admin verification.'
    );
  };

  // Data Reset & Clean Tools
  const handleCleanAllData = () => {
    storage.cleanSlate();
    setProducts([]);
    setClaims([]);
    addToast(
      'info',
      'Clean Slate Ready',
      'All dummy products and claims deleted.'
    );
  };

  const handleResetDemoData = () => {
    storage.resetAllData();
    setProducts(storage.getProducts());
    setClaims(storage.getClaims());
    addToast(
      'info',
      'Demo Data Reset',
      'Loaded fresh demo products, claims, and screenshots.'
    );
  };

  const handleExportCsv = () => {
    const csvContent = storage.exportClaimsAsCsv();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `tbc-wms-claims-ledger-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast('success', 'CSV Exported', 'Claims verification and payout ledger downloaded.');
  };

  const handleOpenLightbox = (imageUrl: string, title: string, subtitle?: string) => {
    setLightboxData({
      isOpen: true,
      imageUrl,
      title,
      subtitle
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification Container */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Offline Mode Indicator for PWA */}
      <OfflineIndicator />

      {/* Proof Lightbox Modal */}
      <ProofLightbox
        isOpen={lightboxData.isOpen}
        onClose={() => setLightboxData((prev) => ({ ...prev, isOpen: false }))}
        imageUrl={lightboxData.imageUrl}
        title={lightboxData.title}
        subtitle={lightboxData.subtitle}
      />

      {/* Customer Dedicated Login & Sign Up Modal */}
      <LoginModal
        isOpen={isCustomerLoginModalOpen}
        onClose={() => setIsCustomerLoginModalOpen(false)}
        onLoginSuccess={handleCustomerLoginSuccess}
        lang={language}
      />

      {/* Dedicated Admin Login Modal (Accessible only via #admin) */}
      <AdminLoginModal
        isOpen={isAdminLoginModalOpen}
        onClose={() => setIsAdminLoginModalOpen(false)}
        onLoginSuccess={handleAdminLoginSuccess}
        lang={language}
      />

      {/* ========================================================================= */}
      {/* PORTAL ROUTER: Completely Separated Customer & Admin Portals              */}
      {/* ========================================================================= */}
      {activePortal === 'admin' ? (
        isAdminLoggedIn && adminUser ? (
          <AdminPortal
            products={products}
            claims={claims}
            currentUser={adminUser}
            currentTheme={currentTheme}
            themeConfig={themeConfig}
            language={language}
            setLanguage={setLanguage}
            onSelectTheme={handleSelectTheme}
            onSwitchToCustomer={() => handleSwitchPortal('customer')}
            onOpenCustomerLogin={() => setIsCustomerLoginModalOpen(true)}
            onOpenAdminLogin={() => setIsAdminLoginModalOpen(true)}
            onLogout={handleAdminLogout}
            onSaveProduct={handleSaveProduct}
            onDeleteProduct={handleDeleteProduct}
            onToggleProductStatus={handleToggleProductStatus}
            onApproveClaim={handleApproveClaim}
            onRejectClaim={handleRejectClaim}
            onConfirmPayout={handleConfirmPayout}
            onCleanAllData={handleCleanAllData}
            onResetDemoData={handleResetDemoData}
            onExportCsv={handleExportCsv}
            onShowToast={addToast}
            onOpenLightbox={handleOpenLightbox}
          />
        ) : (
          <AdminLoginModal
            isOpen={true}
            isFullScreen={true}
            onBackToCustomer={() => handleSwitchPortal('customer')}
            onLoginSuccess={handleAdminLoginSuccess}
            lang={language}
          />
        )
      ) : (
        <CustomerPortal
          products={products}
          claims={claims}
          customerSession={customerSession}
          isLoggedIn={isCustomerLoggedIn}
          language={language}
          setLanguage={setLanguage}
          themeConfig={themeConfig}
          onOpenCustomerLogin={() => setIsCustomerLoginModalOpen(true)}
          onLogout={handleCustomerLogout}
          onSubmitClaim={handleSubmitCustomerClaim}
          onShowToast={addToast}
          onOpenLightbox={handleOpenLightbox}
        />
      )}
    </div>
  );
}
