// Vercel Serverless Function Handler for /api/*
import type { Request, Response } from 'express';

const INITIAL_PRODUCTS = [
  {
    id: 'PROD-101',
    title: 'Noise-Cancelling Wireless Headphones Pro',
    brand: 'AcousticWave',
    platform: 'Amazon',
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700&q=80',
    originalPrice: 2499,
    cashbackAmount: 2499,
    cashbackType: '100% Free',
    specialCode: 'AMZ-ANC-99',
    purchaseUrl: 'https://www.amazon.in',
    totalSlots: 50,
    claimedSlots: 0,
    status: 'active',
    instructions: [
      'Search product on Amazon using our direct link',
      'Place order and pay standard checkout price',
      'Leave 5-star review upon delivery with 2 photos',
      'Upload 3 screenshots here for 100% full refund'
    ],
    createdAt: '2026-09-20'
  },
  {
    id: 'PROD-102',
    title: 'Smart AMOLED Fitness Tracker Watch v4',
    brand: 'PulseFit',
    platform: 'Flipkart',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700&q=80',
    originalPrice: 1999,
    cashbackAmount: 1500,
    cashbackType: 'Flat Cashback',
    specialCode: 'FLP-BAND-44',
    purchaseUrl: 'https://www.flipkart.com',
    totalSlots: 40,
    claimedSlots: 0,
    status: 'active',
    instructions: [
      'Search on Flipkart store',
      'Verify merchant is PulseFit Official',
      'Submit screenshots within 48 hours of delivery'
    ],
    createdAt: '2026-09-21'
  },
  {
    id: 'PROD-103',
    title: 'Organic Arabica Dark Roast Coffee Beans 500g',
    brand: 'CafeArtisan',
    platform: 'Blinkit',
    imageUrl: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=700&q=80',
    originalPrice: 650,
    cashbackAmount: 650,
    cashbackType: '100% Free',
    specialCode: 'BLK-COFF-12',
    purchaseUrl: 'https://blinkit.com',
    totalSlots: 60,
    claimedSlots: 0,
    status: 'active',
    instructions: [
      'Order via Blinkit 10-minute delivery',
      'Rating & invoice screenshot required'
    ],
    createdAt: '2026-09-22'
  },
  {
    id: 'PROD-104',
    title: 'Ergonomic Precision Wireless Gaming Mouse',
    brand: 'ViperGear',
    platform: 'Amazon',
    imageUrl: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=700&q=80',
    originalPrice: 1299,
    cashbackAmount: 1000,
    cashbackType: 'Flat Cashback',
    specialCode: 'AMZ-MOU-88',
    purchaseUrl: 'https://www.amazon.in',
    totalSlots: 35,
    claimedSlots: 0,
    status: 'active',
    instructions: [
      'Buy through direct link',
      'Review after 3 days of testing with unboxing picture'
    ],
    createdAt: '2026-09-23'
  }
];

let memoryProducts: any[] = [...INITIAL_PRODUCTS];
let memoryClaims: any[] = [];
let memoryDeletedIds: string[] = [];

export default function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const url = req.url || '';

  // SSE Events stream compatibility for Vercel
  if (url.includes('/events')) {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    const active = memoryProducts.filter((p: any) => p && p.id && !memoryDeletedIds.includes(p.id));
    res.write(`data: ${JSON.stringify({
      type: 'CONNECTED',
      products: active,
      deletedProductIds: memoryDeletedIds,
      timestamp: Date.now()
    })}\n\n`);
    return res.end();
  }

  // Deleted Product IDs endpoint
  if (url.includes('/deleted-product-ids')) {
    return res.status(200).json({ deletedProductIds: memoryDeletedIds });
  }

  // Products routes
  if (url.includes('/products')) {
    const isIdSubpath = /\/products\/([^/?]+)/.exec(url);
    const productId = isIdSubpath ? isIdSubpath[1] : null;

    if (req.method === 'GET') {
      const active = memoryProducts.filter((p: any) => p && p.id && !memoryDeletedIds.includes(p.id));
      return res.status(200).json({ products: active, deletedProductIds: memoryDeletedIds, updatedAt: Date.now() });
    }

    if (req.method === 'POST') {
      const product = req.body;
      if (product && product.id) {
        if (memoryDeletedIds.includes(product.id) && !url.includes('forceUndelete=true')) {
          const active = memoryProducts.filter((p: any) => p && p.id && !memoryDeletedIds.includes(p.id));
          return res.status(409).json({ error: 'Product is permanently deleted', deletedProductIds: memoryDeletedIds, products: active });
        }
        const idx = memoryProducts.findIndex((p: any) => p.id === product.id);
        if (idx !== -1) {
          memoryProducts[idx] = { ...memoryProducts[idx], ...product };
        } else {
          memoryProducts.unshift(product);
        }
      }
      const active = memoryProducts.filter((p: any) => p && p.id && !memoryDeletedIds.includes(p.id));
      return res.status(200).json({ success: true, products: active, deletedProductIds: memoryDeletedIds });
    }

    if (req.method === 'PUT' && productId) {
      const updates = req.body || {};
      const idx = memoryProducts.findIndex((p: any) => p.id === productId);
      if (idx === -1) {
        return res.status(404).json({ error: 'Product not found' });
      }
      memoryProducts[idx] = { ...memoryProducts[idx], ...updates };
      return res.status(200).json({ success: true, product: memoryProducts[idx], products: memoryProducts });
    }

    if (req.method === 'DELETE' && productId) {
      if (!memoryDeletedIds.includes(productId)) {
        memoryDeletedIds.push(productId);
      }
      memoryProducts = memoryProducts.filter((p: any) => p.id !== productId);
      const active = memoryProducts.filter((p: any) => p && p.id && !memoryDeletedIds.includes(p.id));
      return res.status(200).json({ success: true, products: active, deletedProductIds: memoryDeletedIds, deletedId: productId });
    }
  }

  // Claims routes
  if (url.includes('/claims')) {
    const isClaimIdSubpath = /\/claims\/([^/?]+)/.exec(url);
    const claimId = isClaimIdSubpath ? isClaimIdSubpath[1] : null;

    if (req.method === 'GET') {
      return res.status(200).json({ claims: memoryClaims, updatedAt: Date.now() });
    }

    if (req.method === 'POST') {
      const claim = req.body;
      if (claim && claim.id) {
        memoryClaims.unshift(claim);
        const prod = memoryProducts.find((p: any) => p.id === claim.productId);
        if (prod) {
          prod.claimedSlots = (prod.claimedSlots || 0) + 1;
        }
      }
      return res.status(200).json({ success: true, claim, claims: memoryClaims });
    }

    if (req.method === 'PUT' && claimId) {
      const updates = req.body || {};
      const idx = memoryClaims.findIndex((c: any) => c.id === claimId);
      if (idx === -1) {
        return res.status(404).json({ error: 'Claim not found' });
      }
      memoryClaims[idx] = { ...memoryClaims[idx], ...updates };
      return res.status(200).json({ success: true, claim: memoryClaims[idx], claims: memoryClaims });
    }
  }

  // Clean Slate route
  if (url.includes('/clean-slate')) {
    memoryProducts.forEach((p: any) => {
      if (p && p.id && !memoryDeletedIds.includes(p.id)) {
        memoryDeletedIds.push(p.id);
      }
    });
    INITIAL_PRODUCTS.forEach((p: any) => {
      if (p && p.id && !memoryDeletedIds.includes(p.id)) {
        memoryDeletedIds.push(p.id);
      }
    });
    memoryProducts = [];
    memoryClaims = [];
    return res.status(200).json({ success: true, products: [], claims: [], deletedProductIds: memoryDeletedIds });
  }

  // Reset Demo route
  if (url.includes('/reset-demo')) {
    memoryDeletedIds = [];
    memoryProducts = [...INITIAL_PRODUCTS];
    memoryClaims = [];
    return res.status(200).json({ success: true, message: 'Reset to demo catalog', products: memoryProducts, claims: memoryClaims });
  }

  return res.status(200).json({ status: 'ok' });
}
