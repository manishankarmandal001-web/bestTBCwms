# TBC WMS Cashback & Rewards Portal

Production-grade full-stack portal with instant real-time synchronization, campaign tracking, proof verification, and automated payouts.

---

## 🚀 Deployment Guide (Vercel & Hostinger)

### 1. Deploying on Vercel
This repository is pre-configured for Vercel with `vercel.json` and a serverless API handler in `/api`.

1. Push this project to GitHub / GitLab / Bitbucket.
2. In Vercel Dashboard, click **Add New...** > **Project** and import your repository.
3. Vercel will automatically detect the settings:
   - **Framework Preset**: `Vite`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `npm install --legacy-peer-deps` (configured in `vercel.json`)
4. Click **Deploy**.
5. Your application and all `/api/*` endpoints will be live immediately without build or routing errors!

---

### 2. Deploying on Hostinger

You can deploy on Hostinger using either **Node.js Web App** (recommended for full backend sync) or **Static Hosting** (for simple SPA hosting).

#### Method A: Hostinger Node.js Application (Recommended)
1. In Hostinger hPanel, go to **Websites** > **Manage** > **Node.js**.
2. Upload this project archive or clone via Git.
3. Configure the Node.js settings:
   - **Node.js version**: `18.x`, `20.x`, `22.x`, or `24.x`
   - **Application root**: `/public_html` (or your subdomain directory)
   - **Application startup file**: `server.js` (Root startup file is already provided)
4. Click **Run npm install** (or open SSH / Web Terminal and run `npm install`).
5. Run the build command:
   ```bash
   npm run build
   ```
6. Click **Restart** or start the Node.js application.
7. Everything runs smoothly on port `3000` / assigned host port!

#### Method B: Hostinger Static Web Hosting
1. Build the production files:
   ```bash
   npm run build
   ```
2. Upload the entire contents of the `dist/` directory into your `public_html` folder.
3. The included `dist/.htaccess` file ensures all routes (like `/admin`, `/claims`, etc.) rewrite properly to `index.html` without 404 errors.

---

## 💻 Local Development

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the dev server:
   ```bash
   npm run dev
   ```
3. Open `http://localhost:3000`.
