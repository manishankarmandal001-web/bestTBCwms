/**
 * Hostinger Production Entry Point
 * Compatible with Hostinger Node.js Application Manager, cPanel, and VPS.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const distServer = path.resolve(__dirname, 'dist', 'server.js');
const distHtml = path.resolve(__dirname, 'dist', 'index.html');

if (fs.existsSync(distServer)) {
  await import('./dist/server.js');
} else if (fs.existsSync(distHtml)) {
  // If Vite build was run independently, serve Vite static build
  const express = (await import('express')).default;
  const app = express();
  const PORT = process.env.PORT || 3000;
  const distPath = path.resolve(__dirname, 'dist');
  app.use(express.static(distPath));
  app.get('*', (req, res) => res.sendFile(distHtml));
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Vite application running on http://0.0.0.0:${PORT}`);
  });
} else {
  await import('./server.ts');
}
